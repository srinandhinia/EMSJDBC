package com.cg.ems.dao;

public interface QueryMapper 
{
	public static final String SELECTQRY1 = "SELECT *  FROM emp160633";
	public static final String SELECTQRY2 = "SELECT *  FROM emp160633"
			+ " WHERE emp_id = ?";
	public static final String INSERTQRY1 = 
			"INSERT INTO emp160633 VALUES(333,'Sunil',34000,'12-Jan-2018')";
	public static final String INSERTQRY2 = 
			"INSERT INTO emp160633 VALUES(emp_id,emp_name,emp_sal)" +
	                "VALUES(444,'Amit',60000)";
	public static final String INSERTQRY3 = 
			"INSERT INTO emp160633(emp_id,emp_name,emp_sal)" +
	                "VALUES(?,?,?)";
	public static final String UPDATEQRY = "UPDATE emp160633 SET emp_name = ?,emp_sal = ? WHERE emp_id=?";
	public static final String DELETEQRY = "DELETE emp160633 WHERE emp_id=?";
    public static final String SEARCHQRY1 = "SELECT * FROM emp160633 WHERE emp_id = ?";
    public static final String SEARCHQRY2 = "SELECT * FROM emp160633 WHERE emp_name = ?";
    



}
