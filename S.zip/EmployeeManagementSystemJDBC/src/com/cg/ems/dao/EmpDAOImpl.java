package com.cg.ems.dao;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashSet;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmpDAOImpl implements EmpDAO{

    Connection con = null;
    Statement st = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
	
	@Override
	public int addEmployee(Employee ee) throws EmployeeException 
	{
		try
		{
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.INSERTQRY3);
			pst.setInt(1, ee.getEmpId());
			pst.setString(2, ee.getEmpName());
			pst.setFloat(3, ee.getEmpSal());
			int data = pst.executeUpdate();
			if(data == 1)
			{
				return ee.getEmpId();
			}
			else
			{
				return 0;
			}
			
		}
		catch (Exception e)
		{
			//e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
			
		}
		
		
	}

	@Override
	public HashSet<Employee> fetchAllEmp() 
	{
		HashSet<Employee> empSet = new HashSet<Employee>();
		
		try
		{
			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery(QueryMapper.SELECTQRY1);
			while(rs.next())
			{
				int eid = rs.getInt("emp_id");
				String enm = rs.getString("emp_name");
				float sl = rs.getFloat("emp_Sal");
				empSet.add(new Employee(eid,enm,sl));
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return empSet;
		
	}

	@Override
	public Employee getEmpById(int empId)
	{
				return null;
		
	}

	@Override
	public HashSet<Employee> searchEmpByName(String name) 
	{
		
		return null;
				
	}

	@Override
	public int deleteEmp(int empId) throws EmployeeException
	{
		
		try
		{
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.DELETEQRY);
			pst.setInt(1, empId);
			int data = pst.executeUpdate();
			
			System.out.println("Data is deleted");
			if(data == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}
			
			
			
		}
		catch (Exception e)
		{
			//e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		
	}

	@Override
	public Employee updateEmp(int eid, String newName, float newSal) 
	{
		Employee empSet = null;
		
		try
		{
			con = DBUtil.getCon();
			pst = con.prepareStatement(QueryMapper.UPDATEQRY);
			pst.setString(1, newName);
			pst.setFloat(2, newSal);
			pst.setInt(3, eid);
			int data = pst.executeUpdate();
			empSet = new Employee(eid,newName,newSal);
			System.out.println("Data is updated");
			if(data == 1)
			{
				return empSet;
			}
			else
			{
				return null;
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
			//throw new EmployeeException(e.getMessage());
		}
		return null;
		
		
		
		
	}

}
