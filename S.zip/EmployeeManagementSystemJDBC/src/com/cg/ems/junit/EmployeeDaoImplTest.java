package com.cg.ems.junit;

import java.time.LocalDate;

import org.junit.*;

import com.cg.ems.dao.EmpDAO;
import com.cg.ems.dao.EmpDAOImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public class EmployeeDaoImplTest {

	static EmpDAO empdao=null;
	@BeforeClass
	public static void setUp()
	{
		empdao=new EmpDAOImpl();
	}
	
	@Test
	public void addEmpTest() throws EmployeeException
	{
		Assert.assertEquals(111,empdao.addEmployee(new Employee(111,"aaa",1111.0F,LocalDate.now())));
	}
	
}
